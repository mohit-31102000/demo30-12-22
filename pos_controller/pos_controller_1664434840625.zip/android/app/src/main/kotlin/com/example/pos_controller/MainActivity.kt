package com.example.pos_controller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
